#include <DHT.h>

#define PIN_N 12
#define PIN_P 14
#define PIN_K 27
#define PIN_LDR 34
#define PIN_DHT 15
#define PIN_RELE 22

#define DHTTYPE DHT22
DHT dht(PIN_DHT, DHTTYPE);

void setup() {
  Serial.begin(115200);

  pinMode(PIN_N, INPUT_PULLUP);
  pinMode(PIN_P, INPUT_PULLUP);
  pinMode(PIN_K, INPUT_PULLUP);

  pinMode(PIN_RELE, OUTPUT);
  digitalWrite(PIN_RELE, LOW);

  dht.begin();

  Serial.println("===============================================");
  Serial.println("  FarmTech Solutions - Sistema de Irrigacao    ");
  Serial.println("===============================================");
}
void loop() {
  bool temN = (digitalRead(PIN_N) == LOW);
  bool temP = (digitalRead(PIN_P) == LOW);
  bool temK = (digitalRead(PIN_K) == LOW);

  int valorLDR = analogRead(PIN_LDR);
  float phSolo = map(valorLDR, 0, 4095, 0, 140) / 10.0;

  float umidadeSolo = dht.readHumidity();

  Serial.print("[NUTRIENTES] N: "); Serial.print(temN ? "OK" : "FALTA");
  Serial.print(" | P: "); Serial.print(temP ? "OK" : "FALTA");
  Serial.print(" | K: "); Serial.println(temK ? "OK" : "FALTA");

  Serial.print("[PARAMETROS] pH Solo: "); Serial.print(phSolo);
  Serial.print(" | Umidade Solo: "); Serial.print(umidadeSolo); Serial.println("%");

  if (isnan(umidadeSolo)) {
    Serial.println(">>> SENSOR: dado de umidade invalido. Irrigacao desligada.");
    digitalWrite(PIN_RELE, LOW);
    Serial.println("-----------------------------------------------");
    delay(2000);
    return;
  }

  bool soloSeco = (umidadeSolo < 60.0);
  bool phIdeal = (phSolo >= 5.5 && phSolo <= 6.5);

  if (soloSeco && phIdeal) {
    digitalWrite(PIN_RELE, HIGH);
    Serial.println(">>> DECISÃO: [IRRIGAÇÃO LIGADA] Solo seco e pH adequado.");
  } else {
    digitalWrite(PIN_RELE, LOW);
    Serial.println(">>> DECISÃO: [IRRIGAÇÃO DESLIGADA]");
  }

  Serial.println("-----------------------------------------------");
  delay(2000);
}
